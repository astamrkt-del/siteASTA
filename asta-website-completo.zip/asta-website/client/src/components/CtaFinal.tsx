import { motion } from "framer-motion";
import { FaWhatsapp } from "react-icons/fa";

const WA = "https://wa.me/5521982291150";

export default function CtaFinal() {
  return (
    <section className="bg-card border-t border-border py-20 md:py-28 px-6 md:px-8">
      <div className="max-w-[640px] mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center gap-6"
        >
          <motion.h2
            initial={{ opacity: 0, scale: 0.97 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1], delay: 0.05 }}
            className="text-2xl md:text-4xl font-semibold text-foreground leading-tight"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            Descubra quanto você está deixando de ganhar.
          </motion.h2>

          <p
            className="text-base text-muted-foreground max-w-[480px] leading-relaxed"
            style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 300 }}
          >
            Análise gratuita. Sem compromisso. Vamos fazer o máximo possível para encontrar oportunidades reais de crescimento.
          </p>

          {/* Subtle attention pulse on the CTA button */}
          <motion.div
            animate={{ boxShadow: ["0 0 0px rgba(21,99,235,0)", "0 0 30px rgba(21,99,235,0.4)", "0 0 0px rgba(21,99,235,0)"] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="rounded-full mt-4"
          >
            <motion.a
              href={WA}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="button-cta-whatsapp"
              whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.2 }}
              style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 500, letterSpacing: "0.01em" }}
              className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white px-8 py-3.5 rounded-full text-sm transition-all duration-200 w-full sm:w-auto leading-none shadow-lg hover:shadow-xl"
            >
              <FaWhatsapp className="w-4 h-4 shrink-0" />
              <span>Agendar análise gratuita agora</span>
            </motion.a>
          </motion.div>

        </motion.div>
      </div>
    </section>
  );
}
