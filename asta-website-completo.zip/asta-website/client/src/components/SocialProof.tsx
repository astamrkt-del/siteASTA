import { motion } from "framer-motion";
import { Star, ChevronRight } from "lucide-react";
import { useRef } from "react";

const testimonials = [
  {
    name: "Dr. João Silva",
    result: "Agenda lotada, clínica organizada",
    quote: "Vocês reorganizaram tudo. Agora a clínica funciona como deve funcionar. Os pacientes vêm, voltam e indicam.",
    stars: 5,
  },
  {
    name: "Dra. Marina Costa",
    result: "Crescimento real na agenda",
    quote: "Não é só números. A clínica está mais organizada, o atendimento melhorou e os pacientes voltam.",
    stars: 5,
  },
  {
    name: "Dr. Carlos Mendes",
    result: "Pacientes de qualidade, não quantidade",
    quote: "Vocês focaram em trazer os pacientes certos. Isso fez toda a diferença no resultado.",
    stars: 5,
  },
  {
    name: "Dra. Ana Paula",
    result: "Transformação na gestão da clínica",
    quote: "Mais organização, mais pacientes, menos desperdício. Simples assim.",
    stars: 5,
  },
];

export default function SocialProof() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollContainerRef.current) {
      const scrollAmount = 400;
      scrollContainerRef.current.scrollBy({
        left: direction === "right" ? scrollAmount : -scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="py-20 md:py-28 px-6 md:px-8 bg-gradient-to-b from-primary/10 to-primary/5 border-t border-primary/20">
      <div className="max-w-[1160px] mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block">Histórias Reais</span>
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            O que dizem nossos clientes
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-base md:text-lg">
            Clínicas que transformaram sua realidade com a ASTA.
          </p>
        </motion.div>

        {/* Testimonials Carousel */}
        <div className="relative">
          <div
            ref={scrollContainerRef}
            className="flex gap-6 overflow-x-auto scroll-smooth pb-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          >
            {testimonials.map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.4, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="flex-shrink-0 w-full md:w-[calc(50%-12px)] lg:w-[calc(33.333%-16px)] bg-background border border-border rounded-[20px] p-7 md:p-8 hover:border-primary/30 transition-all duration-300 hover:shadow-[0_0_24px_-6px_rgba(21,99,235,0.15)]"
              >
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.stars)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-foreground mb-6 leading-relaxed italic" style={{ fontFamily: "Poppins, sans-serif" }}>
                  "{testimonial.quote}"
                </p>

                {/* Result Badge */}
                <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-4">
                  <div className="text-sm text-foreground font-medium">{testimonial.result}</div>
                </div>

                {/* Name */}
                <div>
                  <div className="font-semibold text-foreground" style={{ fontFamily: "Montserrat, sans-serif" }}>
                    {testimonial.name}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>


        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.4, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mt-16"
        >
          <p className="text-muted-foreground mb-6">
            Sua clínica pode ser a próxima. Vamos analisar seu potencial.
          </p>
          <motion.a
            href="https://wa.me/5521982291150"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05, boxShadow: "0 8px 24px rgba(21,99,235,0.4)" }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center justify-center bg-primary hover:bg-primary/90 text-white px-8 py-3.5 rounded-full font-semibold transition-all duration-200 shadow-lg"
          >
            Agendar análise gratuita
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
