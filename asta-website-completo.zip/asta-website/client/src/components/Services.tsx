import { MousePointerClick, Smartphone, Workflow, LineChart, Cpu, Rocket } from "lucide-react";
import { motion } from "framer-motion";

const services = [
  { icon: <MousePointerClick className="w-4 h-4" />, title: "Tráfego Pago", description: "Google Ads, Meta Ads, estratégia de mídia" },
  { icon: <Smartphone className="w-4 h-4" />, title: "Posicionamento Digital", description: "Presença, reputação e autoridade" },
  { icon: <Workflow className="w-4 h-4" />, title: "Gestão de Processos", description: "CRM, fluxos de atendimento e conversão" },
  { icon: <LineChart className="w-4 h-4" />, title: "Inteligência de Dados", description: "Dashboards, métricas e decisões precisas" },
  { icon: <Cpu className="w-4 h-4" />, title: "Tecnologia", description: "Automações, integrações e ferramentas" },
  { icon: <Rocket className="w-4 h-4" />, title: "Estratégia de Crescimento", description: "Planejamento e execução orientada a metas" },
];

export default function Services() {
  return (
    <section id="services" className="py-16 md:py-24 px-6 md:px-8 border-y border-border/40">
      <div className="max-w-[1160px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="mb-12"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block">O Que Fazemos</span>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground">O ecossistema completo</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="group bg-card border border-card-border rounded-[18px] p-5 md:p-6 transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_24px_-6px_rgba(21,99,235,0.2)] flex items-start gap-4"
            >
              <motion.div 
                className="w-9 h-9 rounded-lg border border-border flex items-center justify-center text-muted-foreground shrink-0 mt-0.5 transition-all duration-300 group-hover:border-primary/40 group-hover:text-primary group-hover:bg-primary/12"
                whileHover={{ scale: 1.15 }}
              >
                {s.icon}
              </motion.div>
              <div>
                <h3 className="text-sm font-semibold text-card-foreground mb-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>{s.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 300 }}>{s.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
