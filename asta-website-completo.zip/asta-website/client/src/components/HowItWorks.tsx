import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const steps = [
  {
    num: "01",
    title: "Diagnóstico Estratégico",
    description:
      "Antes de qualquer campanha, analisamos sua clínica, seu posicionamento, seus concorrentes e identificamos os gargalos que estão limitando seu crescimento.",
  },
  {
    num: "02",
    title: "Estratégia Personalizada",
    description:
      "Com base nos dados, construímos um plano exclusivo para a realidade da sua clínica. Nada de fórmulas prontas ou estratégias genéricas.",
  },
  {
    num: "03",
    title: "Execução e Otimização",
    description:
      "Implementamos, acompanhamos diariamente os indicadores e refinamos continuamente cada ação para gerar mais pacientes e crescimento previsível.",
  },
];

function Step({ step, index }: { step: typeof steps[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });

  return (
    <div ref={ref}>
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={inView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.4, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex gap-6 md:gap-8"
      >
        {/* Animated number pill */}
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={inView ? { scale: 1, opacity: 1 } : {}}
          transition={{ duration: 0.35, delay: index * 0.1 + 0.05, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center shrink-0 pt-0.5"
        >
          <div className="w-9 h-9 rounded-full border border-primary/30 bg-primary/8 flex items-center justify-center">
            <span
              className="text-xs font-medium text-primary tabular-nums"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              {step.num}
            </span>
          </div>
        </motion.div>

        {/* Content */}
        <div className="pb-10 md:pb-12">
          <motion.h3
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.35, delay: index * 0.1 + 0.1 }}
            className="text-base md:text-lg font-semibold text-foreground mb-2"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            {step.title}
          </motion.h3>
          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.35, delay: index * 0.1 + 0.18 }}
            className="text-sm md:text-base text-muted-foreground leading-relaxed"
            style={{ fontFamily: "Poppins, sans-serif", fontWeight: 300 }}
          >
            {step.description}
          </motion.p>
        </div>
      </motion.div>

      {/* Animated connector arrow */}
      {index < steps.length - 1 && (
        <motion.div
          initial={{ opacity: 0, scaleY: 0 }}
          animate={inView ? { opacity: 1, scaleY: 1 } : {}}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.3, ease: "easeOut" }}
          style={{ transformOrigin: "top" }}
          className="flex gap-6 md:gap-8 mb-2"
        >
          <div className="w-9 flex justify-center shrink-0">
            <div className="flex flex-col items-center gap-0.5">
              <div className="w-px h-5 bg-border" />
              <span className="text-primary/40 text-sm leading-none">↓</span>
            </div>
          </div>
          <div />
        </motion.div>
      )}
    </div>
  );
}

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-16 md:py-24 px-6 md:px-8 border-y border-border/40">
      <div className="max-w-[1160px] mx-auto">

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block">
            Como Funciona
          </span>
          <h2
            className="text-2xl md:text-3xl font-semibold text-foreground"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Da análise à previsibilidade.
          </h2>
        </motion.div>

        <div className="flex flex-col max-w-[640px]">
          {steps.map((step, i) => (
            <Step key={i} step={step} index={i} />
          ))}
        </div>

      </div>
    </section>
  );
}
