import { FaInstagram, FaWhatsapp } from "react-icons/fa";
import { Mail } from "lucide-react";
const logoSrc = "/manus-storage/772767_fa52a308.jpg";

const WA = "https://wa.me/5521982291150";

export default function Footer() {
  return (
    <footer className="bg-background border-t border-border py-10 md:py-12 px-6 md:px-8">
      <div className="max-w-[1160px] mx-auto flex flex-col md:flex-row justify-between items-center gap-6">

        <div className="flex items-center gap-3">
          <div className="h-8 w-8 overflow-hidden rounded-md flex items-center justify-center bg-black shrink-0">
            <img src={logoSrc} alt="ASTA Logo" className="h-full w-full object-cover" />
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-base tracking-tight text-foreground" style={{ fontFamily: 'Montserrat, sans-serif' }}>ASTA</span>
            <span className="text-xs text-muted-foreground">Crescimento previsível para clínicas.</span>
          </div>
        </div>

        <div className="flex flex-col items-center md:items-end gap-4">
          <div className="flex items-center gap-3">
            <a
              href="https://instagram.com/astagrowth_"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="link-footer-instagram"
              className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors duration-200"
            >
              <FaInstagram className="w-4 h-4" />
            </a>
            <a
              href={WA}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="link-footer-whatsapp"
              className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors duration-200"
            >
              <FaWhatsapp className="w-4 h-4" />
            </a>
            <a
              href="mailto:astamkt@gmail.com"
              data-testid="link-footer-email"
              className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors duration-200"
            >
              <Mail className="w-4 h-4" />
            </a>
          </div>
          <p className="text-xs text-muted-foreground">
            © 2026 ASTA. Todos os direitos reservados.
          </p>
        </div>

      </div>
    </footer>
  );
}
