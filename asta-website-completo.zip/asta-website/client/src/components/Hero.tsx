import { useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { FaWhatsapp } from "react-icons/fa";

const WA = "https://wa.me/5521982291150";

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);

  // Cursor light tracking
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const x = useSpring(rawX, { stiffness: 80, damping: 20 });
  const y = useSpring(rawY, { stiffness: 80, damping: 20 });

  function handleMouseMove(e: React.MouseEvent<HTMLElement>) {
    const rect = sectionRef.current?.getBoundingClientRect();
    if (!rect) return;
    rawX.set(e.clientX - rect.left);
    rawY.set(e.clientY - rect.top);
  }

  // Parallax on headline: very subtle vertical offset on scroll is not used here;
  // instead we do a gentle scale on mount for the title (scale in)

  return (
    <section
      ref={sectionRef}
      onMouseMove={handleMouseMove}
      className="relative pt-28 pb-20 md:pt-40 md:pb-28 px-6 md:px-8 overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #000000 0%, #0a0a0a 50%, #050505 100%)"
      }}
    >
      {/* Subtle overlay */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20" />

      {/* Very subtle blue accent — top-right */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(21,99,235,0.08) 0%, transparent 70%)" }}
      />

      {/* Cursor-following light — very subtle */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background: useTransform(
            [x, y],
            ([lx, ly]) =>
              `radial-gradient(380px circle at ${lx}px ${ly}px, rgba(37,99,235,0.04) 0%, transparent 60%)`
          ),
        }}
      />

      <div className="max-w-[1160px] mx-auto flex flex-col items-start text-left relative z-10">

        {/* Integrated Urgency Banner */}
        <div className="w-full bg-gradient-to-r from-primary/15 to-primary/10 border border-primary/25 rounded-[12px] p-4 md:p-5 mb-10 backdrop-blur-sm">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  Apenas {5} vagas restantes para análise gratuita
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Próximas vagas encerram em breve
                </p>
              </div>
            </div>
            <a
              href="https://wa.me/5521982291150"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-semibold text-primary hover:text-primary/80 transition-colors whitespace-nowrap"
            >
              Garantir vaga →
            </a>
          </div>
        </div>

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut", delay: 0.05 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/20 bg-primary/5 mb-10"
        >
          <span className="relative flex h-1.5 w-1.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-primary" />
          </span>
          <span className="text-xs text-primary/80 tracking-wide">✓ 17 clínicas | Metodologia comprovada</span>
        </motion.div>

        {/* Headline — scale in */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.97, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1], delay: 0.12 }}
          className="text-[2.5rem] leading-[1.1] md:text-[3.5rem] lg:text-[4.25rem] font-semibold text-foreground tracking-tight mb-6 max-w-[700px]"
          style={{ fontFamily: "Montserrat, sans-serif" }}
        >
          Você está deixando de <span className="text-primary">faturar</span>.
        </motion.h1>

        {/* Subheadline — fade up */}
        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut", delay: 0.22 }}
          className="text-base md:text-lg text-muted-foreground max-w-[580px] leading-relaxed mb-10"
          style={{ fontFamily: "Poppins, sans-serif", fontWeight: 300 }}
        >
          Analisamos sua clínica. Mostramos exatamente onde estão os vazamentos de leads. E quanto você pode ganhar corrigindo. Crescimento real, sem promessas vazias.
        </motion.p>

        {/* Buttons — staggered */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut", delay: 0.32 }}
          className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto"
        >
          <motion.a
            href={WA}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="button-hero-primary"
            whileHover={{ scale: 1.05, boxShadow: "0 8px 24px rgba(21,99,235,0.4)" }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.2 }}
            style={{ fontFamily: "Poppins, sans-serif", fontWeight: 600, letterSpacing: "0.01em" }}
            className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white px-7 py-3.5 rounded-full text-sm transition-all duration-200 shadow-lg w-full sm:w-auto leading-none"
          >
            <FaWhatsapp className="w-4 h-4 shrink-0" />
            <span>Agendar análise gratuita</span>
          </motion.a>

          <motion.a
            href="#how-it-works"
            data-testid="button-hero-secondary"
            whileHover={{ scale: 1.02, backgroundColor: "rgba(255,255,255,0.08)" }}
            whileTap={{ scale: 0.98 }}
            transition={{ duration: 0.15 }}
            style={{ fontFamily: "Poppins, sans-serif", fontWeight: 500, letterSpacing: "0.01em" }}
            className="inline-flex items-center justify-center bg-transparent hover:bg-white/5 border border-border text-foreground px-7 py-3.5 rounded-full text-sm transition-all duration-200 w-full sm:w-auto leading-none"
          >
            Ver resultados reais
          </motion.a>
        </motion.div>

      </div>
    </section>
  );
}
