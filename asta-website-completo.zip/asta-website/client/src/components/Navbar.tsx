import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
const logoSrc = "/manus-storage/asta-logo-real_7fece7ba.png";

const WA = "https://wa.me/5521982291150";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const links = [
    { href: "#benefits", label: "Por que a ASTA" },
    { href: "#how-it-works", label: "Como Funciona" },
    { href: "#services", label: "Serviços" },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-md border-b border-border py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-[1160px] mx-auto px-6 md:px-8 flex items-center justify-between">

        <a href="#" className="flex items-center gap-2.5">
          <div className="h-8 w-8 overflow-hidden rounded-md flex items-center justify-center bg-black shrink-0">
            <img src={logoSrc} alt="ASTA Logo" className="h-full w-full object-cover" />
          </div>
          <span
            className="font-bold text-lg tracking-tight text-foreground"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            ASTA
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-7">
          {links.map((l) => (
            <motion.a
              key={l.href}
              href={l.href}
              whileHover={{ color: "#F5F5F5" }}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors duration-200"
            >
              {l.label}
            </motion.a>
          ))}
          <motion.a
            href={WA}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="button-nav-cta"
            whileHover={{ scale: 1.05, boxShadow: "0 4px 20px rgba(21,99,235,0.4)" }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center bg-primary hover:bg-primary/90 text-white font-medium text-sm px-5 py-2.5 rounded-full transition-all duration-200 shadow-md"
          >
            Falar com especialista
          </motion.a>
        </nav>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2 text-foreground"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-mobile-menu"
          aria-label="Menu"
        >
          {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="md:hidden bg-background border-b border-border overflow-hidden"
          >
            <div className="px-6 py-5 flex flex-col gap-1">
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-base font-medium text-foreground py-3 border-b border-border/40 last:border-0"
                >
                  {l.label}
                </a>
              ))}
              <a
                href={WA}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="mt-4 inline-flex items-center justify-center bg-primary hover:bg-primary/90 text-white font-semibold px-6 py-4 rounded-full text-base transition-colors duration-200 w-full"
              >
                Falar com especialista
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
