import { CheckCircle, Users, LineChart, Clock } from "lucide-react";
import { motion } from "framer-motion";

const diffs = [
  { icon: <CheckCircle className="w-5 h-5 text-primary" />, title: "Método proprietário", description: "Sistema validado com dezenas de clínicas" },
  { icon: <Users className="w-5 h-5 text-primary" />, title: "Time especializado", description: "Profissionais focados exclusivamente em saúde" },
  { icon: <LineChart className="w-5 h-5 text-primary" />, title: "Foco em resultado", description: "Métricas claras e relatórios mensais" },
  { icon: <Clock className="w-5 h-5 text-primary" />, title: "Processo contínuo", description: "Acompanhamento permanente, sem contratos rígidos" },
];

export default function Differentials() {
  return (
    <section className="py-16 md:py-24 px-6 md:px-8">
      <div className="max-w-[1160px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="mb-12"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block">Nossos Diferenciais</span>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground">Por que somos diferentes</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {diffs.map((d, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -6, transition: { duration: 0.2 } }}
              className="group bg-card border border-card-border rounded-[20px] p-6 md:p-8 transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_32px_-8px_rgba(21,99,235,0.25)] flex items-start gap-5"
            >
              <motion.div 
                className="w-11 h-11 rounded-xl bg-primary/10 border border-primary/15 flex items-center justify-center shrink-0 transition-all duration-300 group-hover:bg-primary/20 group-hover:border-primary/40"
                whileHover={{ scale: 1.12 }}
              >
                {d.icon}
              </motion.div>
              <div>
                <h3 className="text-base font-semibold text-card-foreground mb-1.5" style={{ fontFamily: 'Montserrat, sans-serif' }}>{d.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 300 }}>
                  {d.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
