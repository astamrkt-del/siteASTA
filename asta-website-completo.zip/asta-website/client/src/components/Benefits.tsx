import { Target, BarChart2, Shield } from "lucide-react";
import { motion } from "framer-motion";

const cards = [
  {
    icon: <Target className="w-5 h-5 text-primary" />,
    title: "Análise profunda antes de qualquer ação",
    description: "Entendemos sua clínica por completo. Só depois disso, sabemos o que fazer.",
  },
  {
    icon: <BarChart2 className="w-5 h-5 text-primary" />,
    title: "Resultados reais, não promessas",
    description: "Nossos clientes crescem porque fazemos o trabalho certo. Sem atalhos.",
  },
  {
    icon: <Shield className="w-5 h-5 text-primary" />,
    title: "Transparência total",
    description: "Você sabe exatamente o que estamos fazendo e por quê. Sem mistérios.",
  },
];

export default function Benefits() {
  return (
    <section id="benefits" className="py-16 md:py-24 px-6 md:px-8">
      <div className="max-w-[1160px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="mb-12"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block">Por que escolher ASTA</span>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground max-w-2xl">O que torna nossas clínicas diferentes</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          {cards.map((card, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -6, transition: { duration: 0.2 } }}
              className="group bg-card border border-card-border rounded-[20px] p-7 md:p-8 shadow-sm transition-all duration-300 hover:border-primary/30 hover:shadow-[0_0_32px_-8px_rgba(21,99,235,0.25)]"
            >
              <motion.div 
                className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/15 flex items-center justify-center mb-5 transition-all duration-300 group-hover:bg-primary/20 group-hover:border-primary/40"
                whileHover={{ scale: 1.1 }}
              >
                {card.icon}
              </motion.div>
              <h3 className="text-base font-semibold text-card-foreground mb-2" style={{ fontFamily: 'Montserrat, sans-serif' }}>{card.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 300 }}>
                {card.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
