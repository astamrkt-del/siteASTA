import { motion } from "framer-motion";
import { Clock, AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";

export default function UrgencyBanner() {
  const [slotsLeft, setSlotsLeft] = useState(5);
  const [timeLeft, setTimeLeft] = useState("2d 14h");

  useEffect(() => {
    // Simular countdown
    const interval = setInterval(() => {
      // Aqui você pode adicionar lógica real de countdown
      // Por enquanto, mantemos estático para não confundir
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: [0, 1, 1, 0], y: [-20, 0, 0, -20] }}
      transition={{ duration: 8, times: [0, 0.1, 0.8, 1], repeat: Infinity, ease: "easeInOut" }}
      className="fixed top-20 left-0 right-0 z-40 px-6 md:px-8 pointer-events-none"
      onMouseEnter={(e) => (e.currentTarget.style.pointerEvents = 'auto')}
      onMouseLeave={(e) => (e.currentTarget.style.pointerEvents = 'none')}
    >
      <div className="max-w-[1160px] mx-auto bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30 rounded-[12px] p-4 md:p-5 backdrop-blur-md pointer-events-auto">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <AlertCircle className="w-5 h-5 text-primary shrink-0" />
            </motion.div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                🔥 Apenas {slotsLeft} vagas restantes para análise gratuita
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                <Clock className="w-3 h-3 inline mr-1" />
                Próximas vagas encerram em {timeLeft}
              </p>
            </div>
          </div>
          <motion.a
            href="https://wa.me/5521982291150"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="text-xs font-semibold text-primary hover:text-primary/80 transition-colors whitespace-nowrap"
          >
            Garantir vaga →
          </motion.a>
        </div>
      </div>
    </motion.div>
  );
}
