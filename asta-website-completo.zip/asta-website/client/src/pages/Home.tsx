import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import SocialProof from "../components/SocialProof";
import Benefits from "../components/Benefits";
import HowItWorks from "../components/HowItWorks";
import Services from "../components/Services";
import Differentials from "../components/Differentials";
import CtaFinal from "../components/CtaFinal";
import Footer from "../components/Footer";
import ScrollProgress from "../components/ScrollProgress";

export default function Home() {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/20 selection:text-primary">
      <ScrollProgress />
      <Navbar />
      <main className="flex-1">
        <Hero />
        <SocialProof />
        <Benefits />
        <HowItWorks />
        <Services />
        <Differentials />
        <CtaFinal />
      </main>
      <Footer />
    </div>
  );
}
