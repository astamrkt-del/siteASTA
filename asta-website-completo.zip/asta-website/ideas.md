# ASTA - Design Philosophy

## Design Approach: Premium Tech Minimalism

A landing page premium para uma empresa de crescimento para clínicas, inspirada em empresas de tecnologia de alto padrão como Apple, Stripe, Linear, Vercel, Notion, Framer e Raycast.

### Core Design Philosophy

**ASTA** é uma empresa de tecnologia e estratégia, não uma agência de marketing genérica. O design deve transmitir:
- **Elegância**: Refinamento em cada detalhe
- **Sofisticação**: Escolhas deliberadas e precisas
- **Tecnologia**: Moderna, confiável, inovadora
- **Autoridade**: Especialista, confiante, estabelecida
- **Minimalismo**: Menos é mais; cada elemento tem propósito

### Color Philosophy

**Paleta Principal:**
- **Fundo**: #000000 (preto absoluto) - transmite sofisticação e tecnologia
- **Azul Primário**: #1563EB (azul profundo) - confiança, crescimento, tecnologia
- **Branco**: #FFFFFF - clareza, simplicidade
- **Cinzas Discretos**: Para hierarquia e sutileza

**Raciocínio**: O preto absoluto como fundo cria um contraste elegante com o azul e branco. O azul é a cor de identidade - presente em todas as interações, mas nunca excessivo. Cinzas criam hierarquia visual sem distrair.

### Layout Paradigm

**Estrutura Assimétrica e Fluida:**
- Seções com layouts variados (não grid centralizado repetitivo)
- Uso estratégico de whitespace para respiração visual
- Elementos alinhados à esquerda ou com composição dinâmica
- Transições suaves entre seções com dividers e gradientes sutis

### Signature Elements

1. **Glow Azul Sutil**: Auras de luz azul (#1563EB com baixa opacidade) que aparecem em backgrounds e ao redor de elementos interativos
2. **Badges Minimalistas**: Pequenos indicadores com ícones animados (pulsing dots) para destacar status/novidade
3. **Cards Elevados**: Bordas finas, sombras suaves, hover effects que levantam o elemento (y: -4px)

### Interaction Philosophy

- **Hover Sofisticado**: Elevação sutil, mudança de cor discreta, sombra aumentada
- **Microinterações**: Botões com scale (1.02 on hover, 0.98 on tap)
- **Animações de Entrada**: Fade up, scale in (0.97 → 1), staggered para grupos
- **Transições Fluidas**: Todas as mudanças com easing custom (cubic-bezier)

### Animation Guidelines

**Timing:**
- Entrada de elementos: 300-450ms
- Hover/tap: 150-200ms
- Scroll reveals: 300-400ms
- Stagger entre itens: 60-100ms

**Easing:**
- Entrada: `cubic-bezier(0.16, 1, 0.3, 1)` (snappy ease-out)
- Hover: `cubic-bezier(0.23, 1, 0.32, 1)` (responsive)
- Transições: `ease-out` para UI, `ease-in-out` para movimento

**Regras:**
- Nunca animar de `scale(0)` - começar de `scale(0.95)`
- Apenas `transform` e `opacity` para performance
- Respeitar `prefers-reduced-motion`
- Nada exagerado - tudo deve parecer profissional e sênior

### Typography System

**Fonts:**
- **Headings**: Montserrat (600-700 weight) - elegante, moderna, autoridade
- **Body/UI**: Poppins (300-500 weight) - limpa, legível, amigável

**Hierarchy:**
- H1: 4.25rem (mobile: 2.5rem) - headline principal
- H2: 3rem (mobile: 2rem) - seção titles
- H3: 1.125rem - card titles
- Body: 1rem - conteúdo principal
- Small: 0.875rem - descrições, labels

**Letter Spacing:**
- Headings: -0.01em (tight, elegante)
- Body: normal
- Labels: +0.05em (uppercase labels com tracking)

### Brand Essence

**Positioning**: Empresa de tecnologia e estratégia que estrutura crescimento previsível para clínicas através de dados, processos e inovação.

**Personality**: Confiante, Inovadora, Precisa

**Brand Voice**:
- Headlines: Diretos, inspiradores, sem clichês
- CTAs: Ação clara, urgência sem pressão
- Microcopy: Profissional, preciso, sem jargão vazio

**Exemplos:**
- ✅ "Crescimento previsível para sua clínica"
- ❌ "Bem-vindo ao nosso site"
- ✅ "Estruturamos clínicas para atrair pacientes de forma consistente"
- ❌ "Soluções inovadoras para seu negócio"

### Brand Logo & Mark

**Logo Mark**: Símbolo geométrico em azul (#1563EB) que combina:
- Dente (saúde/clínica)
- Seta ascendente (crescimento)
- Linhas limpas e modernas

**Uso**: 
- Navbar: 32x32px
- Footer: 32x32px
- Favicon: 16x16px
- Hero: Pode aparecer em versão maior como elemento decorativo

### Signature Brand Color

**#1563EB** - Azul profundo que é imediatamente reconhecível como ASTA. Presente em:
- Botões primários
- Links e hover states
- Badges e indicadores
- Acentos em cards
- Glows e efeitos de luz

### Visual Assets

- **Hero Background**: Imagem dark com elementos de crescimento (gráficos, linhas, glows)
- **Logo**: Símbolo geométrico em azul
- **Dividers**: SVG waves ou linhas diagonais para separar seções
- **Icons**: Lucide React (consistente, minimalista)

### Responsive Design

- **Mobile First**: Design começa em mobile
- **Breakpoints**: sm (640px), md (768px), lg (1024px)
- **Touch Targets**: Mínimo 44x44px para interação
- **Padding**: Aumenta em telas maiores (6px → 8px → 32px)

### Accessibility

- **Contrast**: WCAG AA mínimo (4.5:1 para texto)
- **Focus Rings**: Visíveis e em cor de destaque
- **Keyboard Navigation**: Todos os elementos acessíveis
- **Semantic HTML**: Estrutura correta para leitores de tela

---

## Style Decisions

### Seção Hero
- Background: Imagem dark com glows azuis sutis
- Headline: Montserrat 4.25rem, bold, tracking tight
- Subheadline: Poppins 1.125rem, light, color muted
- Botões: Primário (azul) + Secundário (outline)
- Animações: Fade up + scale in staggered

### Seção Benefits
- 3 cards em grid
- Ícones com background azul sutil
- Hover: Elevação + shadow + border color change
- Animação: Fade up on scroll

### Seção How It Works
- Timeline vertical com números
- Conectores animados
- Staggered entrance
- Border top/bottom da seção

### Seção Services
- 6 cards em grid 3 colunas
- Ícones pequenos com hover color change
- Compact layout
- Hover: Elevação + shadow

### Seção Differentials
- 4 cards em grid 2 colunas
- Ícones maiores
- Descrição clara
- Hover effects consistentes

### Seção CTA Final
- Fundo card color
- Headline grande e impactante
- Botão com pulsing glow animation
- Centered layout

### Footer
- Logo + ASTA text
- Social icons com hover
- Copyright
- Minimal, clean
